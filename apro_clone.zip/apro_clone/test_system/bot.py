import logging
import asyncio
from aiogram import Bot, Dispatcher
from aiogram.types import Message, ReplyKeyboardMarkup, KeyboardButton, ReplyKeyboardRemove
from aiogram.filters import Command
from aiogram.client.default import DefaultBotProperties
from apro.database import Database

TOKEN = "7533969791:AAG1oIlZ01XRRMo6m-G2TH4VDELSWxcBXeQ"

bot = Bot(token=TOKEN, default=DefaultBotProperties(parse_mode="Markdown"))
dp = Dispatcher()
db = Database()

logging.basicConfig(level=logging.INFO)

# Keyboard for requesting phone number
request_contact_kb = ReplyKeyboardMarkup(
    keyboard=[[KeyboardButton(text="📱 Send My Contact", request_contact=True)]],
    resize_keyboard=True,
    one_time_keyboard=True
)

@dp.message(Command("start"))
async def start_command(message: Message):
    await message.answer("💖 Welcome, my dear! A magical journey awaits! 💫\n\n"
                         "With pleasure, may I have your contact information? 🥰",
                         reply_markup=request_contact_kb)

@dp.message(lambda msg: msg.contact is not None)
async def receive_contact(message: Message):
    phone_number = message.contact.phone_number
    await message.answer("✨ You can only receive one login and password. Do you accept? 💕\n\n"
                         "Reply with 'Yes' to continue.",
                         reply_markup=ReplyKeyboardRemove())

    @dp.message(lambda msg: msg.text.lower() == "yes")
    async def confirm_registration(msg: Message):
        success, password = db.create_user(phone_number)
        if success:
            await msg.answer(f"💖 Registration successful! 💫\n\n"
                             f"📞 *Login*: `{phone_number}`\n🔑 *Password*: `{password}`\n\n"
                             f"Keep it safe! 🥰")
        else:
            await msg.answer("Oops! 😢 Something went wrong. Please try again later.")

async def main():
    """Main async function to start the bot."""
    await bot.delete_webhook(drop_pending_updates=True)
    await dp.start_polling(bot)

if __name__ == "__main__":
    asyncio.run(main())