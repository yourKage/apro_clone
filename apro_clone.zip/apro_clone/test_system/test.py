from apro.database import Database

# Create an instance of the Database class
db = Database(db_name='database.db')

# The database is created automatically in the constructor
# You can call other methods on the db instance if needed