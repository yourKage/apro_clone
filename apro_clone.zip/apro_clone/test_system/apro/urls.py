from django.urls import path
from . import views

urlpatterns = [
    path('', views.category_list, name='category_list'),  # List categories
    path('category/<int:category_id>/', views.test_list, name='test_list'), # List tests in category
    path('take_test/<int:test_id>/', views.take_test, name='take_test'), # Take the test
    path('results/<int:user_test_result_id>/', views.results, name='results'),
    path('dashboard/', views.dashboard, name='dashboard'),
    path('user_results/', views.user_results, name='user_results'),
    path('teacher/register/', views.teacher_register, name='teacher_register'),
    path('teacher/login/', views.teacher_login, name='teacher_login'),
    path('teacher/dashboard/', views.teacher_dashboard, name='teacher_dashboard'),
    path('teacher/add_question/', views.add_question, name='add_question'),
    path('teacher/add_test/', views.add_test, name='add_test'),
    path('questions/', views.question_list, name='question_list'),
    path('login/', views.user_login, name='login'),
]