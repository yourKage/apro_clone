from django.shortcuts import render, get_object_or_404, redirect
from .models import Test, Question, Choice, TestQuestion, UserTestResult
from django.contrib.auth.decorators import login_required
from django.shortcuts import render, get_object_or_404, redirect
from .models import Category, Test
from .database import Database



from django.shortcuts import render, redirect, get_object_or_404
from django.contrib.auth import login, authenticate
from .forms import TeacherRegistrationForm, LoginForm, QuestionForm, TestForm
from .models import Teacher, Test, Question, Category
from django.contrib.auth.decorators import login_required, user_passes_test

def teacher_register(request):
    if request.method == 'POST':
        form = TeacherRegistrationForm(request.POST)
        if form.is_valid():
            user = form.save()
            login(request, user)
            return redirect('teacher_dashboard')
    else:
        form = TeacherRegistrationForm()
    return render(request, 'tests/teacher_register.html', {'form': form})


def teacher_login(request):
    if request.method == 'POST':
        form = LoginForm(request.POST)
        if form.is_valid():
            username = form.cleaned_data['username']
            password = form.cleaned_data['password']
            user = authenticate(request, username=username, password=password)
            if user:
                login(request, user)
                return redirect('teacher_dashboard')  # Redirect based on user type
    else:
        form = LoginForm()
    return render(request, 'tests/teacher_login.html', {'form': form})

@login_required
@user_passes_test(lambda u: hasattr(u, 'teacher'), login_url='/teacher/login/')
def teacher_dashboard(request):
    teacher = request.user.teacher
    tests = Test.objects.filter(category=teacher.category)
    return render(request, 'tests/teacher_dashboard.html', {'teacher': teacher, 'tests': tests})

@login_required
@user_passes_test(lambda u: hasattr(u, 'teacher'), login_url='/teacher/login/')
def add_question(request):
    if request.method == 'POST':
        form = QuestionForm(request.POST)
        if form.is_valid():
            form.save()
            return redirect('question_list')
    else:
        form = QuestionForm()
    return render(request, 'tests/add_question.html', {'form': form})

def user_login(request):
    if request.method == 'POST':
        form = LoginForm(request.POST)
        if form.is_valid():
            username = form.cleaned_data['username']
            password = form.cleaned_data['password']
            user = authenticate(request, username=username, password=password)  # No hashing

            if user is not None:
                login(request, user)
                return redirect('dashboard')
            else:
                print("Invalid login credentials")
                form.add_error(None, "Invalid login credentials")
    else:
        form = LoginForm()

    # Debug: Print all users
    db = Database()
    users = db.fetch_all_users()
    db.close()
    print(users)

    return render(request, 'tests/login.html', {'form': form})




@login_required
@user_passes_test(lambda u: hasattr(u, 'teacher'), login_url='/teacher/login/')
def add_test(request):
    if request.method == 'POST':
        form = TestForm(request.POST)
        if form.is_valid():
            test = form.save(commit=False)
            test.category = form.cleaned_data['category']  # Set the category field
            test.save()
            # Associate questions with the test
            for question_id in request.POST.getlist('questions'):
                question = Question.objects.get(id=question_id)
                TestQuestion.objects.create(test=test, question=question, points=question.points)
            return redirect('test_list', category_id=test.category.id)  # Provide category_id
    else:
        form = TestForm()
    questions = Question.objects.all()
    return render(request, 'tests/add_tests.html', {'form': form, 'questions': questions})


def take_test(request, test_id):
    test = get_object_or_404(Test, pk=test_id)
    questions = test.testquestion_set.all().order_by('id')

    if request.method == 'POST':
        score = 0
        for question in questions:
            question_id = question.question.id
            question_type = question.question.question_type
            user_answer = request.POST.getlist(f'question_{question_id}')

            if question_type == 'single' or question_type == 'multiple':
                for choice_id_str in user_answer:
                    try:
                        choice_id = int(choice_id_str)
                        chosen_choice = Choice.objects.get(pk=choice_id)
                        print(chosen_choice)
                        score += chosen_choice.points  # Add the specific points for the choice
                    except Choice.DoesNotExist:
                        pass

            elif question_type == 'short':
                correct_answer = question.question.choices.filter(is_correct=True).first()
                if correct_answer:
                    user_answer_text = request.POST.get(f'question_{question_id}', '').strip()
                    if user_answer_text.lower() == correct_answer.text.lower().strip():
                        score += correct_answer.points  # Add points for correct short answer

        user_test_result = UserTestResult.objects.create(user=request.user, test=test, score=score)

        return redirect('results', user_test_result_id=user_test_result.id)

    context = {'test': test, 'questions': questions}
    return render(request, 'tests/take_test.html', context)


def results(request, user_test_result_id):  # Correct: user_test_result_id
    user_test_result = get_object_or_404(UserTestResult, pk=user_test_result_id)
    context = {'result': user_test_result}
    return render(request, 'tests/results.html', context)


@login_required
def dashboard(request):
    db = Database()
    user_details = None
    if request.user.is_authenticated:
        user_data = db.fetch_user_by_username(request.user.username)
        if user_data:
            user_details = {
                'id': user_data[0],
                'username': user_data[1],
                'password': user_data[2]
            }
    db.close()

    return render(request, 'tests/dashboard.html', {'user_details': user_details})



@login_required
def user_results(request):
    user_results = UserTestResult.objects.filter(user=request.user).order_by('-date_taken')
    context = {'user_results': user_results}
    return render(request, 'tests/user_results.html', context)




def category_list(request):
    categories = Category.objects.all()
    return render(request, 'tests/category_list.html', {'categories': categories})

def test_list(request, category_id):
    category = get_object_or_404(Category, pk=category_id)
    tests = Test.objects.filter(category=category)  # Filter tests by category
    return render(request, 'tests/test_list.html', {'category': category, 'tests': tests})


@login_required
@user_passes_test(lambda u: hasattr(u, 'teacher'), login_url='/teacher/login/')
def question_list(request):
    questions = Question.objects.all()
    return render(request, 'tests/question_list.html', {'questions': questions})