from django import forms
from django.contrib.auth.models import User
from .models import Teacher, Category, Question, Test, Choice

class TeacherRegistrationForm(forms.ModelForm):
    password = forms.CharField(widget=forms.PasswordInput, label="Password")
    category = forms.CharField(max_length=255, label="Category (or select from below)", required=False)
    existing_category = forms.ModelChoiceField(queryset=Category.objects.all(), empty_label="Select Existing Category", required=False)

    class Meta:
        model = User
        fields = ('username', 'email', 'first_name', 'last_name')

    def clean(self):
        cleaned_data = super().clean()
        category = cleaned_data.get('category')
        existing_category = cleaned_data.get('existing_category')

        if not category and not existing_category:
            raise forms.ValidationError("Please enter a category or select an existing one.")

        if category and existing_category:
            raise forms.ValidationError("Please enter a category or select an existing one, not both")

        return cleaned_data

    def save(self, commit=True):
        user = super().save(commit=False)
        user.set_password(self.cleaned_data['password'])
        if commit:
            user.save()

            category_name = self.cleaned_data.get('category') or self.cleaned_data.get('existing_category')
            category, created = Category.objects.get_or_create(name=category_name)

            teacher = Teacher.objects.create(user=user, category=category)
        return user


class LoginForm(forms.Form):
    username = forms.CharField()
    password = forms.CharField(widget=forms.PasswordInput)




class QuestionForm(forms.ModelForm):
    choice_texts = forms.CharField(widget=forms.Textarea, help_text="Enter choices separated by new lines.")
    correct_choice = forms.CharField(help_text="Enter the correct choice text.")

    class Meta:
        model = Question
        fields = ['text', 'question_type', 'points']

    def save(self, commit=True):
        question = super().save(commit=False)
        if commit:
            question.save()
            choices = self.cleaned_data['choice_texts'].split('\n')
            correct_choice_text = self.cleaned_data['correct_choice']
            for choice_text in choices:
                is_correct = (choice_text.strip() == correct_choice_text.strip())
                Choice.objects.create(question=question, text=choice_text.strip(), is_correct=is_correct, points=question.points)

                
        return question
    


class TestForm(forms.ModelForm):
    class Meta:
        model = Test
        fields = ['name', 'description', 'category']