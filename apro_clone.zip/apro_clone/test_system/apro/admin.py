from django.contrib import admin
from .models import Question, Choice, Test, Category, TestQuestion, UserTestResult, Teacher

admin.site.register(Question)
admin.site.register(Choice)
admin.site.register(Test)
admin.site.register(Category)
admin.site.register(TestQuestion) # Register the through model
admin.site.register(UserTestResult) 
admin.site.register(Teacher)