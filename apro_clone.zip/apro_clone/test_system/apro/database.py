import sqlite3
import os
import random
import string

class Database:
    def __init__(self, db_name='database.db'):
        self.db_name = db_name
        self.connection = None
        self.create_database()

    def create_database(self):
        if not os.path.exists(self.db_name):
            self.connection = sqlite3.connect(self.db_name)
            self.create_tables()
        else:
            self.connection = sqlite3.connect(self.db_name)

    def create_tables(self):
        with self.connection:
            self.connection.execute('''
                CREATE TABLE IF NOT EXISTS auth_user (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    username VARCHAR(150) NOT NULL UNIQUE,
                    password VARCHAR(128) NOT NULL
                );
            ''')

    def generate_password(self, length=8):
        characters = string.ascii_letters + string.digits
        return ''.join(random.choice(characters) for i in range(length))

    def create_user(self, username):
        password = self.generate_password()
        try:
            with self.connection:
                self.connection.execute('''
                    INSERT INTO auth_user (username, password)
                    VALUES (?, ?)
                ''', (username, password))
            return True, password
        except sqlite3.IntegrityError:
            return False, None

    def fetch_all_users(self):
        with self.connection:
            cursor = self.connection.execute('SELECT * FROM auth_user')
            return cursor.fetchall()
        
    def fetch_user_by_username(self, username):
        with self.connection:
            cursor = self.connection.execute('SELECT * FROM auth_user WHERE username = ?', (username,))
            return cursor.fetchone()

    def close(self):
        if self.connection:
            self.connection.close()