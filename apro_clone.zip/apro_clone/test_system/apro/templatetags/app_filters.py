from django import template

register = template.Library()

@register.filter
def get_item(dictionary, key):
    return dictionary.get(key)

@register.filter
def attr(obj, arg):
    return getattr(obj, arg)


@register.filter
def nth(iterable, n):
    """Returns the nth element of a list (zero-based index)."""
    try:
        return iterable[n]
    except (IndexError, TypeError):
        return None